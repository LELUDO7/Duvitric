 INSERT INTO categorie(categorie)
    VALUES ("Rallonge"),("Thermostat"),("Ampoule"),("Interrupteur"),("Boite/Jonction"),("Prise"),("Câble"),("Douille"),("Outils");